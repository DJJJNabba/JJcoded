import os
import sys
import ctypes
import subprocess

def is_admin():
    """Check if the script is being run as an administrator."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() == 1
    except:
        return False

def run_as_admin():
    """Re-run the script with administrator privileges."""
    script = os.path.abspath(sys.argv[0])
    params = ' '.join([f'"{arg}"' for arg in sys.argv[1:]])
    
    # Use ShellExecute to re-run the script with admin privileges
    try:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', None, 1)
        sys.exit(0)
    except Exception as e:
        print(f"Failed to re-launch script as administrator: {e}")
        input("Press Enter to exit...")
        sys.exit(1)

def install_certificate(cert_path):
    """Install the certificate to the Trusted Root Certification Authorities store."""
    try:
        subprocess.run(["certutil", "-addstore", "Root", cert_path], check=True)
        print(f"Successfully installed the certificate: {cert_path}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to install the certificate. Error: {e}")
        input("Press Enter to exit...")
        sys.exit(1)

if __name__ == "__main__":
    # Check if the script is being run as an administrator
    if not is_admin():
        print("This script must be run as an administrator!")
        run_as_admin()

    # Path to the certificate (adjust this if necessary)
    cert_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "JJcodedCert.cer")

    # Ensure the certificate file exists
    if not os.path.exists(cert_path):
        print(f"Certificate file not found: {cert_path}")
        input("Press Enter to exit...")
        sys.exit(1)

    # Install the certificate
    install_certificate(cert_path)

    # Pause at the end to keep the terminal open
    input("Press Enter to close...")


import shutil

def copy_file(src, dst):
    shutil.copy(src, dst)

if __name__ == "__main__":
    copy_file('main.py', 'main2.py')

# This script converts an old level map into a new JSON format by associating map characters with texture paths.

import json  # Import the JSON library for saving and loading data

old_level_map = [ # Define the old level map as a list of strings (each character represents a block type)
                 # Each "X" represents a block, "F" represents food, "W" represents water, etc.
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                                                                                      X",
    "X                                      XXXXXXXXXX                                                      X",
    "XXXXX                                  X                                                               X",
    "X     F               E                X        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    "XP        W   X   F     X     W           W  F  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
]

textures = { # Define a dictionary mapping each block type to its respective texture paths
    "X": [ # Block textures
        "textures/blocks/stone_texture.png",
        "textures/blocks/grass_texture.png",
        "textures/blocks/dirt_texture.png"
    ],
    "F": [ # Food textures
        "textures/food/food_texture_frame_1.png",
        "textures/food/food_texture_frame_2.png",
        "textures/food/food_texture_frame_3.png",
        "textures/food/food_texture_frame_4.png",
        "textures/food/food_texture_frame_5.png",
        "textures/food/food_texture_frame_6.png",
        "textures/food/food_texture_frame_7.png",
        "textures/food/food_texture_frame_8.png",
        "textures/food/food_texture_frame_9.png",
        "textures/food/food_texture_frame_10.png",
        "textures/food/food_texture_frame_11.png",
        "textures/food/food_texture_frame_12.png",
        "textures/food/food_texture_frame_13.png",
        "textures/food/food_texture_frame_14.png",
        "textures/food/food_texture_frame_15.png",
        "textures/food/food_texture_frame_16.png",
        "textures/food/food_texture_frame_17.png",
        "textures/food/food_texture_frame_18.png",
        "textures/food/food_texture_frame_19.png",
        "textures/food/food_texture_frame_20.png",
        "textures/food/food_texture_frame_21.png",
        "textures/food/food_texture_frame_22.png",
        "textures/food/food_texture_frame_23.png"
    ],
    "W": [ # Water texture
        "textures/water/water_texture.png"
    ],
    "P": [ # Player texture
        "textures/player/player_texture.png"
    ],
    "E": [ # Enemy texture
        "textures/enemy/enemy_texture.png"
    ],
    "O": [ # Object textures (e.g., helicopter)
        "textures/heli/heli_texture1.png",
        "textures/heli/heli_texture2.png"
    ]
}

new_level = []  # Initialize an empty list to store the new level data
for y, row in enumerate(old_level_map):  # Iterate over each row and its index in the old level map
    for x, cell in enumerate(row):  # Iterate over each character (block type) and its index in the row
        if cell in textures:  # If the character is a recognized block type
            new_level.append({  # Append a new block data dictionary to the new level list
                "x": x,  # X-coordinate of the block
                "y": y,  # Y-coordinate of the block
                "type": cell,  # Block type (e.g., "X", "F")
                "texture_index": 0  # Default texture index (can be customized later)
            })

new_data = {  # Create a dictionary to hold the new level data and textures
    "level": new_level,  # The converted level data
    "textures": textures  # The textures associated with the block types
}

with open('new_level.json', 'w') as file:  # Open a file to save the new level data
    json.dump(new_data, file, indent=4)  # Write the new level data to the file in JSON format

print("New level saved as new_level.json")  # Print a confirmation message

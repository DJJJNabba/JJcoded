import pygame  # Import the Pygame library for creating the game window and handling events
import json  # Import the JSON library for saving and loading level data
import os  # Import the OS library for file handling
import math  # Import the Math library for mathematical calculations
from items import Food, Water  # Import the Food and Water classes from the items module
from block import Block  # Import the Block class from the block module
from player import Player  # Import the Player class from the player module
from enemy import Enemy  # Import the Enemy class from the enemy module
from object import Object  # Import the Object class from the object module
from main_menu import pause_menu  # Import the pause_menu function from the main_menu module

# Initialize Pygame
pygame.init()  # Initialize all Pygame modules

# Constants
SCREEN_WIDTH = 1280  # Set the width of the screen (must be a multiple of 32 for grid alignment)
SCREEN_HEIGHT = 736  # Set the height of the screen (must be a multiple of 32 for grid alignment)
GRID_SIZE = 32  # Set the size of each grid cell (32x32 pixels)
PANEL_WIDTH = 75  # Set the width of the selection panel
PANEL_COLOR = (50, 50, 50, 128)  # Set the color of the panel (semi-transparent gray)
PANEL_BORDER_COLOR = (255, 255, 255)  # Set the color of the panel border (white)
HIGHLIGHT_COLOR = (255, 255, 0)  # Set the color for highlighting selected items (yellow)
BACKGROUND_COLOR = (131, 235, 255)  # Set the background color of the screen (light blue)

# Eraser Constants
ERASER_TEXTURE_PATH = "textures/eraser.png"  # Path to the eraser texture image

# Camera or viewport offsets
camera_x = 0  # Initialize the camera's horizontal offset
camera_y = 0  # Initialize the camera's vertical offset

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.NOFRAME)  # Create a Pygame window with no frame
pygame.display.set_caption("Level Editor")  # Set the window title to "Level Editor"

# Sprite groups
food_group = pygame.sprite.Group()  # Group for all food sprites
water_group = pygame.sprite.Group()  # Group for all water sprites
block_group = pygame.sprite.Group()  # Group for all block sprites
player_group = pygame.sprite.Group()  # Group for all player sprites
enemy_group = pygame.sprite.Group()  # Group for all enemy sprites
object_group = pygame.sprite.Group()  # Group for all object sprites

selected_texture = None  # Initialize the selected texture as None
selected_type = None  # Initialize the selected block type as None

# Paths to the player's textures for different animations
player_texture_paths = {
    'idle': 'textures/dude/Dude_Monster_Idle_4.png',  # Idle animation texture
    'jump': 'textures/dude/Dude_Monster_Jump_8.png',  # Jump animation texture
    'run': 'textures/dude/Dude_Monster_Run_6.png',  # Run animation texture
    'death': 'textures/dude/Dude_Monster_Death_8.png'  # Death animation texture
}

# Paths to the enemy's textures for different animations
enemy_texture_paths = {
    'idle': 'textures/enemy/Owlet_Monster_Idle_4.png',  # Idle animation texture
    'jump': 'textures/enemy/Owlet_Monster_Jump_8.png',  # Jump animation texture
    'run': 'textures/enemy/Owlet_Monster_Run_6.png',  # Run animation texture
    'attack': 'textures/enemy/Owlet_Monster_Walk+Attack_6.png'
}

# Dictionary mapping block types to their corresponding textures
textures = {
    "X": [  # Block textures
        "textures/blocks/stone_texture.png",
        "textures/blocks/grass_texture.png",
        "textures/blocks/dirt_texture.png"
    ],
    "F": [  # Food textures
        "textures/food/food_texture_frame_1.png",
    ],
    "W": [  # Water texture
        "textures/water/water_texture.png"
    ],
    "P": [  # Player textures
        "textures/dude/Dude_Monster_Idle_4.png",
        "textures/dude/Dude_Monster_Jump_8.png",
        "textures/dude/Dude_Monster_Run_6.png",
        "textures/dude/Dude_Monster_Death_8.png"
    ],
    "E": {  # Enemy textures
        'idle': 'textures/enemy/Owlet_Monster_Idle_4.png',
        'jump': 'textures/enemy/Owlet_Monster_Jump_8.png',
        'run': 'textures/enemy/Owlet_Monster_Run_6.png',
        'attack': 'textures/enemy/Owlet_Monster_Walk+Attack_6.png'
    },
    "O": [  # Object textures (e.g., helicopter)
        "textures/heli/heli_texture1.png",
        "textures/heli/heli_texture2.png",
    ]
}

# Load level and textures from JSON
def load_level_from_json(filename):
    if os.path.exists(filename):  # Check if the level file exists
        print(f"Loading level from {filename}")  # Print a message indicating the level is being loaded
        with open(filename, 'r') as file:  # Open the level file in read mode
            data = json.load(file)  # Load the JSON data from the file
        return data['level'], data['textures']  # Return the level map and textures
    else:
        print(f"No saved level found at {filename}")  # Print an error message if the file doesn't exist
        raise FileNotFoundError(f"No saved level found at {filename}")  # Raise a FileNotFoundError

def save_level_to_json(filename, level_map, textures):
    data_to_save = {  # Create a dictionary with the level map and textures
        "level": level_map,  # Save the level map
        "textures": textures  # Save the textures
    }
    with open(filename, 'w') as file:  # Open the file in write mode
        json.dump(data_to_save, file, indent=4)  # Dump the data to the file in JSON format, with indentation for readability

def initialize_map(level_map, textures):
    # Clear all sprite groups to prepare for loading a new level
    block_group.empty()
    food_group.empty()
    water_group.empty()
    player_group.empty()
    enemy_group.empty()
    object_group.empty()
    
    for block_data in level_map:  # Iterate over each block in the level map
        x = block_data['x'] * GRID_SIZE  # Calculate the X position in pixels
        y = block_data['y'] * GRID_SIZE  # Calculate the Y position in pixels
        texture_index = block_data['texture_index']  # Get the texture index
        block_type = block_data['type']  # Get the block type
        
        if block_type == 'X':  # If the block is a regular block
            block = Block(x, y, textures['X'], texture_index)  # Create a Block instance
            block_group.add(block)  # Add the block to the block group
        elif block_type == 'F':  # If the block is food
            food = Food(x, y, textures['F'], texture_index)  # Create a Food instance
            food_group.add(food)  # Add the food to the food group
        elif block_type == 'W':  # If the block is water
            water = Water(x, y, textures['W'], texture_index)  # Create a Water instance
            water_group.add(water)  # Add the water to the water group
        elif block_type == 'P':  # If the block is a player
            player = Player(x, y, player_texture_paths, level_map, GRID_SIZE, texture_index)  # Create a Player instance
            player_group.add(player)  # Add the player to the player group
        elif block_type == 'E':  # If the block is an enemy
            enemy = Enemy(x, y, enemy_texture_paths, GRID_SIZE, texture_index)  # Create an Enemy instance
            enemy_group.add(enemy)  # Add the enemy to the enemy group
        elif block_type == 'O':  # If the block is an object
            object = Object(x, y, textures['O'], texture_index)  # Create an Object instance
            object_group.add(object)  # Add the object to the object group

def update_level_map():
    updated_map = []  # Create an empty list to hold the updated level map
    
    for block in block_group:  # Iterate over all blocks
        updated_map.append({  # Add each block's data to the updated map
            'x': block.rect.x // GRID_SIZE,  # Convert pixel position to grid coordinates
            'y': block.rect.y // GRID_SIZE,  # Convert pixel position to grid coordinates
            'type': 'X',  # Type is 'X' for regular blocks
            'texture_index': block.get_current_texture_index()  # Get the block's current texture index
        })
    
    for object in object_group:  # Iterate over all objects
        updated_map.append({  # Add each object's data to the updated map
            'x': object.rect.x // GRID_SIZE,  # Convert pixel position to grid coordinates
            'y': object.rect.y // GRID_SIZE,  # Convert pixel position to grid coordinates
            'type': 'O',  # Type is 'O' for objects
            'texture_index': object.get_current_texture_index()  # Get the object's current texture index
        })

    for food in food_group:  # Iterate over all food items
        updated_map.append({  # Add each food's data to the updated map
            'x': food.original_x // GRID_SIZE,  # Convert pixel position to grid coordinates
            'y': food.original_y // GRID_SIZE,  # Convert pixel position to grid coordinates
            'type': 'F',  # Type is 'F' for food
            'texture_index': food.get_current_texture_index()  # Get the food's current texture index
        })
    
    for water in water_group:  # Iterate over all water items
        updated_map.append({  # Add each water's data to the updated map
            'x': water.original_x // GRID_SIZE,  # Convert pixel position to grid coordinates
            'y': water.original_y // GRID_SIZE,  # Convert pixel position to grid coordinates
            'type': 'W',  # Type is 'W' for water
            'texture_index': water.get_current_texture_index()  # Get the water's current texture index
        })
    
    for player in player_group:  # Iterate over all players
        updated_map.append({  # Add each player's data to the updated map
            'x': player.rect.x // GRID_SIZE,  # Convert pixel position to grid coordinates
            'y': player.rect.y // GRID_SIZE,  # Convert pixel position to grid coordinates
            'type': 'P',  # Type is 'P' for player
            'texture_index': player.get_current_texture_index()  # Get the player's current texture index
        })
    
    for enemy in enemy_group:  # Iterate over all enemies
        updated_map.append({  # Add each enemy's data to the updated map
            'x': enemy.rect.x // GRID_SIZE,  # Convert pixel position to grid coordinates
            'y': enemy.rect.y // GRID_SIZE,  # Convert pixel position to grid coordinates
            'type': 'E',  # Type is 'E' for enemy
            'texture_index': enemy.current_texture_index  # Get the enemy's current texture index
        })
    
    return updated_map  # Return the updated level map

def move_camera(dx, dy):
    global camera_x, camera_y  # Use global camera offsets
    camera_x += dx  # Move the camera horizontally by dx
    camera_y += dy  # Move the camera vertically by dy

def draw_panel():
    # Draw panel background
    panel_rect = pygame.Rect(SCREEN_WIDTH - PANEL_WIDTH, 0, PANEL_WIDTH, SCREEN_HEIGHT)  # Define the panel's rectangular area
    pygame.draw.rect(screen, PANEL_COLOR, panel_rect)  # Draw the panel's background color
    pygame.draw.rect(screen, PANEL_BORDER_COLOR, panel_rect, 2)  # Draw the panel's border

    # Draw block and item textures
    x_start = SCREEN_WIDTH - PANEL_WIDTH + 5  # Starting X position for the textures
    y_start = 10  # Starting Y position for the textures
    spacing = 75  # Vertical spacing between textures
    
    index = 0  # Index for tracking the position in the panel
    for block_type in textures:  # Iterate over all block types
        for texture_path in (textures[block_type] if block_type == "X" else textures[block_type][:1]):  # Iterate over each texture path (limit to the first texture for non-blocks)
            texture_image = pygame.image.load(texture_path).convert_alpha()  # Load the texture image
            rect = texture_image.get_rect(topleft=(x_start, y_start + index * spacing))  # Get the texture's rect
            
            # Scale the image down to fit in the panel
            scaled_image = pygame.transform.scale(texture_image, (PANEL_WIDTH - 10, PANEL_WIDTH - 10))  # Scale the image to fit within the panel width
            
            # Correct the position of the rect to match the scaled image
            rect = scaled_image.get_rect(topleft=(x_start, y_start + index * spacing))  # Recalculate the rect for the scaled image
            
            # Highlight if mouse is over the texture
            if rect.collidepoint(pygame.mouse.get_pos()):  # If the mouse is over this texture
                pygame.draw.rect(screen, HIGHLIGHT_COLOR, rect.inflate(4, 4), 2)  # Draw a highlight around the texture
            
            screen.blit(scaled_image, rect.topleft)  # Draw the texture image at its position
            index += 1  # Move to the next position in the panel

    # Draw eraser tool at the bottom
    eraser_image = pygame.image.load(ERASER_TEXTURE_PATH).convert_alpha()  # Load the eraser image
    eraser_rect = eraser_image.get_rect(topleft=(x_start, y_start + index * spacing))  # Get the rect for the eraser
    
    # Scale eraser image down to fit in the panel
    scaled_eraser_image = pygame.transform.scale(eraser_image, (PANEL_WIDTH - 10, PANEL_WIDTH - 10))  # Scale the eraser image to fit within the panel width
    
    # Correct the position of the rect to match the scaled image
    eraser_rect = scaled_eraser_image.get_rect(topleft=(x_start, y_start + index * spacing))  # Recalculate the rect for the scaled eraser image
    
    # Highlight eraser if mouse is over it
    if eraser_rect.collidepoint(pygame.mouse.get_pos()):  # If the mouse is over the eraser
        pygame.draw.rect(screen, HIGHLIGHT_COLOR, eraser_rect.inflate(4, 4), 2)  # Draw a highlight around the eraser
    
    screen.blit(scaled_eraser_image, eraser_rect.topleft)  # Draw the eraser image at its position

def get_selected_texture():
    x_start = SCREEN_WIDTH - PANEL_WIDTH + 5  # Starting X position for the textures
    y_start = 10  # Starting Y position for the textures
    spacing = 75  # Vertical spacing between textures
    
    index = 0  # Index for tracking the position in the panel
    for block_type in textures:  # Iterate over all block types
        for texture_path in (textures[block_type] if block_type == "X" else textures[block_type][:1]):  # Iterate over each texture path (limit to the first texture for non-blocks)
            texture_image = pygame.image.load(texture_path).convert_alpha()  # Load the texture image
            rect = texture_image.get_rect(topleft=(x_start, y_start + index * spacing))  # Get the texture's rect
            
            # Adjust rect to match the scaled image
            rect = rect.inflate(PANEL_WIDTH - 10, PANEL_WIDTH - 10)  # Adjust the rect to fit within the panel
            
            if rect.collidepoint(pygame.mouse.get_pos()):  # If the mouse is over this texture
                return block_type, texture_path, index if block_type == "X" else 0  # Return the block type, texture path, and texture index
            
            index += 1  # Move to the next position in the panel
    
    # Check if eraser is selected
    eraser_rect = pygame.Rect(x_start, y_start + index * spacing, PANEL_WIDTH - 10, PANEL_WIDTH - 10)  # Create a rect for the eraser
    if eraser_rect.collidepoint(pygame.mouse.get_pos()):  # If the mouse is over the eraser
        return "eraser", None, None  # Return the eraser as the selected tool
    
    return None, None, None  # Return None if nothing is selected

def draw_world():
    # Draw all blocks, food, and water relative to the camera
    for block in block_group:  # Draw all blocks
        screen.blit(block.image, (block.rect.x - camera_x, block.rect.y - camera_y))  # Draw block relative to camera
    for food in food_group:  # Draw all food items
        screen.blit(food.image, (food.rect.x - camera_x, food.rect.y - camera_y))  # Draw food relative to camera
    for water in water_group:  # Draw all water items
        screen.blit(water.image, (water.rect.x - camera_x, water.rect.y - camera_y))  # Draw water relative to camera
    for player in player_group:  # Draw all players
        screen.blit(player.image, (player.rect.x - camera_x, player.rect.y - camera_y))  # Draw player relative to camera
    for enemy in enemy_group:  # Draw all enemies
        screen.blit(enemy.image, (enemy.rect.x - camera_x, enemy.rect.y - camera_y))  # Draw enemy relative to camera
    for object in object_group:  # Draw all objects
        screen.blit(object.image, (object.rect.x - camera_x, object.rect.y - camera_y))  # Draw object relative to camera

# Start with level1.json
level_file = 'level1.json'  # Set the initial level file
try:
    level_map, textures = load_level_from_json(level_file)  # Try to load the level and textures from JSON
    initialize_map(level_map, textures)  # Initialize the map with the loaded data
except FileNotFoundError as e:  # If the file is not found
    print(e)  # Print the error message
    level_map, textures = [], {"X": ["textures/blocks/stone_texture.png"]}  # Use default textures if file not found
    initialize_map(level_map, textures)  # Initialize the map with default data

# Main editor loop
clock = pygame.time.Clock()  # Create a clock object to manage the frame rate

def main(textures):
    global running, level_file  # Use global variables for running status and level file
    running = True  # Set the running status to True
    while running:
        dt = clock.tick(60) / 1000  # Limit the frame rate to 60 FPS and get the time elapsed since last frame
        
        for event in pygame.event.get():  # Iterate over all Pygame events
            if event.type == pygame.QUIT:  # If the quit event is triggered
                running = False  # Set running to False to exit the loop
            elif event.type == pygame.KEYDOWN:  # If a key is pressed
                if event.key == pygame.K_ESCAPE:  # If the Escape key is pressed
                    pause_menu()  # Call the pause menu
                elif event.key == pygame.K_1:  # If the "1" key is pressed
                    if pygame.key.get_mods() & pygame.KMOD_SHIFT:  # If Shift is also pressed
                        level_map = update_level_map()  # Update the level map with current changes
                        save_level_to_json('level1.json', level_map, textures)  # Save the map to level1.json
                        print("Level saved to level1.json!")  # Print confirmation message
                    else:
                        level_file = 'level1.json'  # Set the level file to level1.json
                        try:
                            level_map, textures = load_level_from_json(level_file)  # Try to load the level from JSON
                            initialize_map(level_map, textures)  # Initialize the map with the loaded data
                            print("Level1 loaded.")  # Print confirmation message
                        except FileNotFoundError as e:  # If the file is not found
                            print(e)  # Print the error message
                elif event.key == pygame.K_2:  # If the "2" key is pressed
                    if pygame.key.get_mods() & pygame.KMOD_SHIFT:  # If Shift is also pressed
                        level_map = update_level_map()  # Update the level map with current changes
                        save_level_to_json('level2.json', level_map, textures)  # Save the map to level2.json
                        print("Level saved to level2.json!")  # Print confirmation message
                    else:
                        level_file = 'level2.json'  # Set the level file to level2.json
                        try:
                            level_map, textures = load_level_from_json(level_file)  # Try to load the level from JSON
                            initialize_map(level_map, textures)  # Initialize the map with the loaded data
                            print("Level2 loaded.")  # Print confirmation message
                        except FileNotFoundError as e:  # If the file is not found
                            print(e)  # Print the error message
                elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:  # If the right arrow or "D" key is pressed
                    move_camera(GRID_SIZE, 0)  # Move the camera to the right
                elif event.key == pygame.K_LEFT or event.key == pygame.K_a:  # If the left arrow or "A" key is pressed
                    move_camera(-GRID_SIZE, 0)  # Move the camera to the left
                elif event.key == pygame.K_DOWN or event.key == pygame.K_s:  # If the down arrow or "S" key is pressed
                    move_camera(0, GRID_SIZE)  # Move the camera down
                elif event.key == pygame.K_UP or event.key == pygame.K_w:  # If the up arrow or "W" key is pressed
                    move_camera(0, -GRID_SIZE)  # Move the camera up
            elif event.type == pygame.MOUSEBUTTONDOWN:  # If a mouse button is clicked
                x, y = event.pos  # Get the mouse position
                grid_x = (x + camera_x) // GRID_SIZE  # Calculate the grid X coordinate
                grid_y = (y + camera_y) // GRID_SIZE  # Calculate the grid Y coordinate
                if x >= SCREEN_WIDTH - PANEL_WIDTH:  # Check if the click is inside the panel
                    if event.button == 1:  # If the left mouse button is clicked
                        selected_type, selected_texture, texture_index = get_selected_texture()  # Get the selected texture
                elif event.button == 3:  # If the right mouse button is clicked
                    if selected_type == "eraser":  # If the eraser is selected
                        # Erase block/food/water
                        for block in block_group:  # Iterate over all blocks
                            if block.rect.collidepoint(x + camera_x, y + camera_y):  # Check if the mouse is over the block
                                block_group.remove(block)  # Remove the block
                        for food in food_group:  # Iterate over all food items
                            if food.rect.collidepoint(x + camera_x, y + camera_y):  # Check if the mouse is over the food
                                food_group.remove(food)  # Remove the food
                        for water in water_group:  # Iterate over all water items
                            if water.rect.collidepoint(x + camera_x, y + camera_y):  # Check if the mouse is over the water
                                water_group.remove(water)  # Remove the water
                        for player in player_group:  # Iterate over all players
                            if player.rect.collidepoint(x + camera_x, y + camera_y):  # Check if the mouse is over the player
                                player_group.remove(player)  # Remove the player
                        for enemy in enemy_group:  # Iterate over all enemies
                            if enemy.rect.collidepoint(x + camera_x, y + camera_y):  # Check if the mouse is over the enemy
                                enemy_group.remove(enemy)  # Remove the enemy
                        for object in object_group:  # Iterate over all objects
                            if object.rect.collidepoint(x + camera_x, y + camera_y):  # Check if the mouse is over the object
                                object_group.remove(object)  # Remove the object
                    elif selected_type and selected_texture:  # If a texture is selected
                        # Place block/food/water
                        if selected_type == 'X':  # If placing a block
                            block = Block(grid_x * GRID_SIZE, grid_y * GRID_SIZE, textures[selected_type], texture_index)  # Create a Block instance
                            block_group.add(block)  # Add the block to the block group
                        elif selected_type == 'F':  # If placing food
                            food = Food(grid_x * GRID_SIZE, grid_y * GRID_SIZE, textures[selected_type], texture_index)  # Create a Food instance
                            food_group.add(food)  # Add the food to the food group
                        elif selected_type == 'W':  # If placing water
                            water = Water(grid_x * GRID_SIZE, grid_y * GRID_SIZE, textures[selected_type], texture_index)  # Create a Water instance
                            water_group.add(water)  # Add the water to the water group
                        elif selected_type == 'P':  # If placing a player
                            # Ensure correct texture paths are being used
                            player_texture_paths = {  # Define the player textures
                                'idle': 'textures/dude/Dude_Monster_Idle_4.png',
                                'jump': 'textures/dude/Dude_Monster_Jump_8.png',
                                'run': 'textures/dude/Dude_Monster_Run_6.png',
                                'death': 'textures/dude/Dude_Monster_Death_8.png'
                            }
                            
                            player = Player(grid_x * GRID_SIZE, grid_y * GRID_SIZE, player_texture_paths, {}, GRID_SIZE, texture_index)  # Create a Player instance
                            player_group.add(player)  # Add the player to the player group
                        elif selected_type == 'E':  # If placing an enemy
                            enemy = Enemy(grid_x * GRID_SIZE, grid_y * GRID_SIZE, enemy_texture_paths, GRID_SIZE, texture_index)  # Create an Enemy instance
                            enemy_group.add(enemy)  # Add the enemy to the enemy group
                        elif selected_type == 'O':  # If placing an object
                            object = Object(grid_x * GRID_SIZE, grid_y * GRID_SIZE, textures[selected_type], texture_index)  # Create an Object instance
                            object_group.add(object)  # Add the object to the object group
        
        food_group.update(dt)  # Update all food items
        water_group.update(dt)  # Update all water items

        # Clear the screen
        screen.fill(BACKGROUND_COLOR)  # Fill the screen with the background color

        # Draw the world (blocks, food, water)
        draw_world()  # Draw all elements in the world

        # Draw the selection panel
        draw_panel()  # Draw the selection panel on the side

        # Update the display
        pygame.display.flip()  # Update the full display surface to the screen

    pygame.quit()  # Quit Pygame when the loop ends

if __name__ == "__main__":
    main()  # Run the main function if this script is executed directly

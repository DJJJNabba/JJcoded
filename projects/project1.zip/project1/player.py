import pygame
from config import GRID_SIZE

# Class representing the player character in the game
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, texture_paths, level_map, grid_size, initial_texture_index=0):
        super().__init__()
        self.level_map = level_map  # The level map data
        self.grid_size = grid_size  # The size of each grid cell
        self.texture_paths = texture_paths  # Dictionary of texture paths for different animations
        self.current_texture_index = initial_texture_index  # Initial texture index
        
        self.PLAYER_SIZE = 32  # Player sprite size (32x32)
        self.animation_frames = {
            'idle': self.load_frames(texture_paths['idle'], 4),  # Load idle animation frames
            'jump': self.load_frames(texture_paths['jump'], 8),  # Load jump animation frames
            'run': self.load_frames(texture_paths['run'], 6),    # Load run animation frames
            'death': self.load_frames(texture_paths['death'], 8) # Load death animation frames
        }
        self.current_animation = 'idle'  # Start with the idle animation
        self.current_frame = 0  # Current frame index for the animation
        self.animation_speed = 0.3  # Speed of the animation
        self.animation_timer = 0  # Timer to control frame updates
        self.facing_right = True  # Track the direction the player is facing
        self.last_damage = 0  # Time since the player last took damage
        
        # Player movement and physics parameters
        self.PLAYER_SPEED = 4  # Movement speed
        self.GRAVITY = 1  # Gravity applied to the player
        self.JUMP_STRENGTH = -12  # Strength of the player's jump
        self.vertical_velocity = 0  # Vertical velocity of the player
        self.on_ground = False  # Whether the player is on the ground
        self.time_since_hit = 0  # Time since the player was last hit

        # Create the player's rect and image based on the initial animation frame
        self.rect = self.animation_frames[self.current_animation][self.current_frame].get_rect(topleft=(x, y))
        self.image = self.animation_frames[self.current_animation][self.current_frame]

        # Create a smaller collision rectangle for more precise collision detection
        self.collision_rect = pygame.Rect(self.rect.x, self.rect.y, 20, 26)
        
        # Player stats
        self.MAX_STAT = 100
        self.FOOD_VALUE = 20
        self.WATER_VALUE = 20
        self.health = self.MAX_STAT  # Start with full health
        self.hunger = self.MAX_STAT  # Start with full hunger
        self.thirst = self.MAX_STAT  # Start with full thirst
        self.inventory = {'food': 0, 'water': 0}  # Inventory for collected items
        self.score = 0  # Player's score
        self.is_dead = False  # Whether the player is dead
        self.death_animation_complete = False  # Whether the death animation is complete
    
    def load_frames(self, texture_path, num_frames):
        # Load the animation frames from a sprite sheet
        sheet = pygame.image.load(texture_path).convert_alpha()
        frames = []
        frame_width = sheet.get_width() // num_frames
        for i in range(num_frames):
            frame = sheet.subsurface(pygame.Rect(i * frame_width, 0, frame_width, self.PLAYER_SIZE))
            frame = pygame.transform.scale(frame, (self.PLAYER_SIZE, self.PLAYER_SIZE))  # Ensure the frame is 32x32
            frames.append(frame)
        return frames

    def update(self, block_group, camera_x, SCREEN_WIDTH, level_map, enemy_group, object_group=None, food_group=None, water_group=None):
        # Update the collision rect position based on the player's current position
        self.collision_rect.topleft = (self.rect.x + (self.PLAYER_SIZE - 20) // 2, self.rect.y + (self.PLAYER_SIZE - 26) // 2)

        if self.health <= 0:
            # If the player's health drops to 0 or below
            if not self.is_dead:
                self.is_dead = True
                self.current_animation = 'death'
                self.current_frame = 0  # Reset to the start of the death animation

            if not self.death_animation_complete:
                self.animate()
                if self.current_frame == len(self.animation_frames['death']) - 1:
                    self.death_animation_complete = True
            else:
                print("death")
                return
        else:
            # Handle player input and movement
            keys = pygame.key.get_pressed()
            previous_animation = self.current_animation

            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                # Move left
                self.rect.x -= self.PLAYER_SPEED
                self.current_animation = 'run'
                self.facing_right = False
            elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                # Move right
                self.rect.x += self.PLAYER_SPEED
                self.current_animation = 'run'
                self.facing_right = True
            else:
                self.current_animation = 'idle'

            if not self.on_ground:
                self.current_animation = 'jump'

            if self.current_animation != previous_animation:
                self.current_frame = 0  # Reset the frame index when the animation changes

            self.animate()

            # Constrain the player's position within the camera's visible area
            self.rect.x = max(camera_x, min(self.rect.x, camera_x + SCREEN_WIDTH - self.PLAYER_SIZE))

            # Horizontal collision detection with blocks
            collided_blocks = pygame.sprite.spritecollide(self, block_group, False)
            for block in collided_blocks:
                if self.rect.right > block.rect.left and self.rect.left < block.rect.left:
                    self.rect.right = block.rect.left
                elif self.rect.left < block.rect.right and self.rect.right > block.rect.right:
                    self.rect.left = block.rect.right

            # Apply gravity
            self.vertical_velocity += self.GRAVITY

            # Jumping logic
            if (keys[pygame.K_UP] and self.on_ground) or (keys[pygame.K_SPACE] and self.on_ground) or (keys[pygame.K_w] and self.on_ground):
                self.vertical_velocity = self.JUMP_STRENGTH
                self.on_ground = False

            # Vertical movement
            self.rect.y += self.vertical_velocity

            # Vertical collision detection with blocks
            collided_blocks = pygame.sprite.spritecollide(self, block_group, False)
            self.on_ground = False  # Reset on_ground flag before checking collisions
            for block in collided_blocks:
                if self.rect.bottom > block.rect.top and self.rect.top < block.rect.top:
                    self.rect.bottom = block.rect.top
                    self.vertical_velocity = 0
                    self.on_ground = True  # Player is on the ground after landing
                elif self.rect.top < block.rect.bottom and self.rect.bottom > block.rect.bottom:
                    self.rect.top = block.rect.bottom
                    self.vertical_velocity = 0

            # Check for collision with objects (e.g., helicopter)
            """object_collisions = pygame.sprite.spritecollide(self, object_group, False)
            if object_collisions:
                from main_menu import next_level_menu
                next_level_menu()"""

            # Proximity-based damage from enemies
            for enemy in enemy_group:
                if self.last_damage >= 20:
                    if (abs(self.rect.centerx - enemy.rect.centerx) <= 50 and
                        abs(self.rect.centery - enemy.rect.centery) <= 50):
                        self.health -= 20  # Reduce health by 20
                        if self.health <= 0:
                            self.is_dead = True
                            self.current_animation = 'death'
                    self.last_damage = 0
                else:
                    self.last_damage += 1

            # Collect food
            food_collisions = pygame.sprite.spritecollide(self, food_group, True)
            if food_collisions:
                for food in food_collisions:
                    self.collect_food()
            
            # Collect water
            water_collisions = pygame.sprite.spritecollide(self, water_group, True)
            if water_collisions:
                for water in water_collisions:
                    self.collect_water()

            # Decrease hunger and thirst over time
            self.hunger -= 0.2
            self.thirst -= 0.25
            if self.hunger <= 0 or self.thirst <= 0:
                self.health -= 0.25

            # Clamp values to a minimum of 0
            self.hunger = max(self.hunger, 0)
            self.thirst = max(self.thirst, 0)
            self.health = max(self.health, 0)

            # Increase score over time
            self.score += 0.1

    def animate(self):
        # Handle animation timing and frame updates
        self.animation_timer += self.animation_speed
        if self.animation_timer >= 1:
            self.animation_timer = 0
            self.current_frame = (self.current_frame + 1) % len(self.animation_frames[self.current_animation])
        
        frame = self.animation_frames[self.current_animation][self.current_frame]
        if not self.facing_right:
            frame = pygame.transform.flip(frame, True, False)  # Flip the frame if the player is facing left
        
        self.image = frame

    def get_current_texture_index(self):
        return self.current_texture_index  # Return the current texture index

    def collect_food(self):
        """Increase the player's hunger stat when collecting food."""
        self.hunger = min(self.hunger + self.FOOD_VALUE, self.MAX_STAT)
        self.health = min(self.health + (self.FOOD_VALUE)/2, self.MAX_STAT)
        self.score += 10

    def collect_water(self):
        """Increase the player's thirst stat when collecting water."""
        self.thirst = min(self.thirst + self.WATER_VALUE, self.MAX_STAT)
        self.health = min(self.health + (self.WATER_VALUE)/2, self.MAX_STAT)
        self.score += 10

import pygame  # Import the Pygame library

class Block(pygame.sprite.Sprite):  # Define a Block class that inherits from pygame.sprite.Sprite
    def __init__(self, x, y, texture_paths, initial_texture_index=0):  # Initialize the Block with position, texture paths, and initial texture index
        super().__init__()  # Initialize the parent class (pygame.sprite.Sprite)
        self.texture_paths = texture_paths  # Store the paths of the textures for this block
        self.current_texture_index = initial_texture_index  # Set the initial texture index
        self.image = pygame.image.load(self.texture_paths[self.current_texture_index]).convert_alpha()  # Load the initial texture image
        self.rect = self.image.get_rect(topleft=(x, y))  # Get the rectangular area of the image and set its top-left position

    def change_texture(self):  # Method to change the block's texture
        self.current_texture_index = (self.current_texture_index + 1) % len(self.texture_paths)  # Cycle through the available textures
        self.image = pygame.image.load(self.texture_paths[self.current_texture_index]).convert_alpha()  # Load the new texture image

    def get_current_texture_index(self):  # Method to get the current texture index
        return self.current_texture_index  # Return the current texture index

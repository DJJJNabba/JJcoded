GRID_SIZE = 32
# Screen dimensions
SCREEN_WIDTH = 1280  # Multiple of 32
SCREEN_HEIGHT = 736  # Multiple of 32
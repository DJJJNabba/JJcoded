import pygame  # Import the Pygame library
import math  # Import the math library for sine wave calculations

class Food(pygame.sprite.Sprite):  # Define a Food class that inherits from pygame.sprite.Sprite
    def __init__(self, x, y, texture_paths, initial_texture_index=0, animation_speed=0.1):  # Initialize the Food with position, textures, and animation speed
        super().__init__()  # Initialize the parent class (pygame.sprite.Sprite)
        self.texture_paths = texture_paths  # Store the texture paths for the food
        self.current_texture_index = initial_texture_index  # Set the initial texture index
        self.current_frame = self.current_texture_index  # Set the current frame to the initial texture index
        self.animation_speed = animation_speed  # Set the speed of the animation
        self.frame_count = len(texture_paths)  # Get the number of frames in the animation
        self.ITEM_SIZE = 32  # Define the size of the food item (32x32 pixels)
        
        self.original_x = x  # Store the original X position (grid-aligned)
        self.original_y = y  # Store the original Y position (grid-aligned)
        
        self.image = pygame.image.load(self.texture_paths[self.current_frame]).convert_alpha()  # Load the initial texture image
        self.rect = self.image.get_rect()  # Get the rectangular area of the image
        self.rect.x = self.original_x  # Set the X position of the rect
        self.rect.y = self.original_y  # Set the Y position of the rect
        
        self.sine_wave_amplitude = 5  # Set the amplitude of the sine wave for vertical movement
        self.time_elapsed = 0  # Initialize the time elapsed for sine wave calculations
    
    def update(self, dt):  # Update the food's position and animation
        self.current_frame = (self.current_frame + self.animation_speed) % self.frame_count  # Advance the animation frame
        self.image = pygame.image.load(self.texture_paths[int(self.current_frame)]).convert_alpha()  # Load the current frame's texture
        
        self.time_elapsed += dt  # Increment the time elapsed
        sine_wave_offset = math.sin(self.time_elapsed * 2 * math.pi) * self.sine_wave_amplitude  # Calculate the vertical offset using a sine wave
        self.rect.y = self.original_y + int(sine_wave_offset)  # Apply the vertical offset to the rect's Y position

    def change_texture(self):  # Change the food's texture
        self.current_texture_index = (self.current_texture_index + 1) % len(self.texture_paths)  # Cycle through available textures
        self.image = pygame.image.load(self.texture_paths[self.current_texture_index]).convert_alpha()  # Load the new texture image

    def get_current_texture_index(self):  # Get the current texture index
        return self.current_texture_index  # Return the current texture index

class Water(pygame.sprite.Sprite):  # Define a Water class that inherits from pygame.sprite.Sprite
    def __init__(self, x, y, texture_paths, initial_texture_index=0, animation_speed=0.1):  # Initialize the Water with position, textures, and animation speed
        super().__init__()  # Initialize the parent class (pygame.sprite.Sprite)
        self.texture_paths = texture_paths  # Store the texture paths for the water
        self.current_texture_index = initial_texture_index  # Set the initial texture index
        self.animation_speed = animation_speed  # Set the speed of the animation
        self.ITEM_SIZE = 32  # Define the size of the water item (32x32 pixels)
        
        self.original_x = x  # Store the original X position (grid-aligned)
        self.original_y = y  # Store the original Y position (grid-aligned)
        
        self.image = pygame.image.load(self.texture_paths[self.current_texture_index]).convert_alpha()  # Load the initial texture image
        self.rect = self.image.get_rect()  # Get the rectangular area of the image
        self.rect.x = self.original_x  # Set the X position of the rect
        self.rect.y = self.original_y  # Set the Y position of the rect
        
        self.sine_wave_amplitude = 5  # Set the amplitude of the sine wave for vertical movement
        self.time_elapsed = 0  # Initialize the time elapsed for sine wave calculations
    
    def update(self, dt):  # Update the water's position and animation
        self.time_elapsed += dt  # Increment the time elapsed
        sine_wave_offset = math.sin(self.time_elapsed * 2 * math.pi) * self.sine_wave_amplitude  # Calculate the vertical offset using a sine wave
        self.rect.y = self.original_y + int(sine_wave_offset)  # Apply the vertical offset to the rect's Y position

    def change_texture(self):  # Change the water's texture
        self.current_texture_index = (self.current_texture_index + 1) % len(self.texture_paths)  # Cycle through available textures
        self.image = pygame.image.load(self.texture_paths[self.current_texture_index]).convert_alpha()  # Load the new texture image

    def get_current_texture_index(self):  # Get the current texture index
        return self.current_texture_index  # Return the current texture index

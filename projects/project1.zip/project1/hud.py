import pygame  # Import the Pygame library

def draw_hud(screen, player, high_score, best_time):  # Function to draw the HUD on the screen
    font = pygame.font.SysFont(None, 36)  # Set up the font for the HUD text
    BAR_WIDTH = 200  # Width of the health, hunger, and thirst bars
    BAR_HEIGHT = 20  # Height of the bars
    RED = (255, 0, 0)  # Color for the background of the bars
    GREEN = (0, 255, 0)  # Color for the health bar
    YELLOW = (255, 255, 0)  # Color for the hunger bar
    CYAN = (0, 255, 255)  # Color for the thirst bar
    BLACK = (0, 0, 0)  # Color for the text

    pygame.draw.rect(screen, RED, (10, 10, BAR_WIDTH, BAR_HEIGHT))  # Draw the background for the health bar
    pygame.draw.rect(screen, GREEN, (10, 10, BAR_WIDTH * (player.health / player.MAX_STAT), BAR_HEIGHT))  # Draw the health bar

    pygame.draw.rect(screen, RED, (10, 40, BAR_WIDTH, BAR_HEIGHT))  # Draw the background for the hunger bar
    pygame.draw.rect(screen, YELLOW, (10, 40, BAR_WIDTH * (player.hunger / player.MAX_STAT), BAR_HEIGHT))  # Draw the hunger bar

    pygame.draw.rect(screen, RED, (10, 70, BAR_WIDTH, BAR_HEIGHT))  # Draw the background for the thirst bar
    pygame.draw.rect(screen, CYAN, (10, 70, BAR_WIDTH * (player.thirst / player.MAX_STAT), BAR_HEIGHT))  # Draw the thirst bar

    # Display current score
    score_text = font.render(f'Score: {int(player.score)}', True, BLACK)  # Create the score text
    screen.blit(score_text, (10, 130))  # Draw the score text on the screen

    # Display high score
    high_score_text = font.render(f'High Score: {int(high_score)}', True, BLACK)
    screen.blit(high_score_text, (10, 100))

    # Display best time
    best_time_text = font.render(f'Best Time: {int(best_time)}s', True, BLACK)
    screen.blit(best_time_text, (10, 160))

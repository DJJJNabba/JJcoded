import pygame
import math

# Class representing an animated object in the game (e.g., a helicopter)
class Object(pygame.sprite.Sprite):
    def __init__(self, x, y, texture_paths, initial_texture_index=0, animation_speed=0.4, sine_wave_amplitude=3, tilt_amplitude=5):
        super().__init__()
        self.texture_paths = texture_paths  # List of texture paths for the object's animation
        self.current_texture_index = initial_texture_index  # Initial texture index
        self.current_frame = self.current_texture_index  # Current animation frame
        self.animation_speed = animation_speed  # Speed of the animation
        self.frame_count = len(texture_paths)  # Total number of frames in the animation
        
        # Store the original grid-aligned position
        self.original_x = x
        self.original_y = y
        
        # Load the initial texture
        self.image = pygame.image.load(self.texture_paths[self.current_frame]).convert_alpha()
        self.rect = self.image.get_rect(topleft=(x, y))
        
        self.sine_wave_amplitude = sine_wave_amplitude  # Amplitude of the sine wave for vertical movement
        self.tilt_amplitude = tilt_amplitude  # Amplitude of the tilt angle
        self.time_elapsed = 0  # Track time for sine wave movement

    def update(self, dt):
        # Update the animation frame
        self.current_frame = (self.current_frame + self.animation_speed) % self.frame_count
        self.image = pygame.image.load(self.texture_paths[int(self.current_frame)]).convert_alpha()
        
        # Apply sine wave movement based on the original position
        self.time_elapsed += dt
        sine_wave_offset = math.sin(self.time_elapsed * 2 * math.pi) * self.sine_wave_amplitude
        self.rect.y = self.original_y + int(sine_wave_offset)
        
        # Link the tilt to the sine wave for vertical movement
        tilt_angle = math.sin(self.time_elapsed * 2 * math.pi) * self.tilt_amplitude
        
        # Apply the tilt by rotating the image
        self.image = pygame.transform.rotate(self.image, tilt_angle)
        
        # Recalculate the rect after rotation to center the sprite correctly
        self.rect = self.image.get_rect(center=self.rect.center)

    def change_texture(self):
        # Cycle through available textures
        self.current_texture_index = (self.current_texture_index + 1) % len(self.texture_paths)
        self.image = pygame.image.load(self.texture_paths[self.current_texture_index]).convert_alpha()

    def get_current_texture_index(self):
        return self.current_texture_index  # Return the current texture index

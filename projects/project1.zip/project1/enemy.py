import pygame  # Import the Pygame library
import random  # Import the random library for generating random numbers

class Enemy(pygame.sprite.Sprite):  # Define an Enemy class that inherits from pygame.sprite.Sprite
    def __init__(self, x, y, texture_paths, level_map, grid_size, initial_texture_index=0):  # Initialize the enemy with position, textures, level map, and other parameters
        super().__init__()  # Initialize the parent class (pygame.sprite.Sprite)
        self.level_map = level_map  # Store the level map reference
        self.grid_size = grid_size  # Store the grid size
        self.texture_paths = texture_paths  # Store the texture paths for the enemy
        self.current_texture_index = initial_texture_index  # Set the initial texture index
        self.ENEMY_SIZE = 32  # Define the size of the enemy (32x32 pixels)
        self.animation_frames = {  # Load the animation frames for different actions
            'idle': self.load_frames(texture_paths['idle'], 4),  # Load idle frames
            'jump': self.load_frames(texture_paths['jump'], 8),  # Load jump frames
            'run': self.load_frames(texture_paths['run'], 6),  # Load run frames
            'attack': self.load_frames(texture_paths['attack'], 6)  # Load attack frames
        }
        self.current_animation = 'idle'  # Start with the idle animation
        self.current_frame = 0  # Initialize the current animation frame index
        self.animation_speed = 0.3  # Set the speed of the animation
        self.animation_timer = 0  # Initialize the animation timer
        self.facing_right = True  # Track the direction the enemy is facing
        self.random_wait = random.randint(30,50)  # Random wait time before action
        self.random_delay = random.randint(11,15)  # Random delay between actions

        self.ENEMY_SPEED = 4  # Set the speed of the enemy's movement
        self.GRAVITY = 1  # Set the gravity applied to the enemy
        self.JUMP_STRENGTH = -13  # Set the strength of the enemy's jump
        self.vertical_velocity = 0  # Start with zero vertical velocity
        self.on_ground = False  # Initialize as not on the ground
        self.rect = self.animation_frames[self.current_animation][self.current_frame].get_rect(topleft=(x, y))  # Get the rect for positioning
        self.image = self.animation_frames[self.current_animation][self.current_frame]  # Set the initial image

        self.collision_rect = pygame.Rect(self.rect.x, self.rect.y, 20, 26)  # Define a smaller collision rect for precise collision detection

        self.state = 'idle'  # Start in the idle state
        self.statedelay = 0  # Initialize the state delay timer
        self.direction = random.choice(['left', 'right'])  # Randomly choose the initial direction
        self.tick = 0  # Initialize the tick counter
        self.timetick = 0  # Initialize the time tick counter

        self.is_attacking = False  # Track if the enemy is currently attacking

    def load_frames(self, texture_path, num_frames):  # Load animation frames from a sprite sheet
        sheet = pygame.image.load(texture_path).convert_alpha()  # Load the sprite sheet image
        frames = []  # Initialize a list to store frames
        frame_width = sheet.get_width() // num_frames  # Calculate the width of each frame

        for i in range(num_frames):  # Iterate through each frame in the sprite sheet
            frame = sheet.subsurface(pygame.Rect(i * frame_width, 0, frame_width, self.ENEMY_SIZE))  # Extract the frame
            frame = pygame.transform.scale(frame, (self.ENEMY_SIZE, self.ENEMY_SIZE))  # Scale the frame to the enemy's size
            frames.append(frame)  # Add the frame to the list

        return frames  # Return the list of frames

    def animate(self):  # Animate the enemy's current action
        num_frames = len(self.animation_frames[self.current_animation])  # Get the number of frames in the current animation

        if self.current_frame >= num_frames:  # Reset the frame index if it exceeds the available frames
            self.current_frame = 0
            if self.current_animation == 'attack':  # If the attack animation is complete
                self.is_attacking = False  # Mark attack as complete

        self.animation_timer += self.animation_speed  # Increment the animation timer
        if self.animation_timer >= 1:  # Advance to the next frame if the timer exceeds the threshold
            self.animation_timer = 0
            self.current_frame = (self.current_frame + 1) % num_frames  # Loop the frame index within the available frames

        frame = self.animation_frames[self.current_animation][self.current_frame]  # Get the current frame

        if not self.facing_right:  # Flip the frame horizontally if the enemy is facing left
            frame = pygame.transform.flip(frame, True, False)

        self.image = frame  # Update the enemy's image with the current frame

    def update(self, block_group, SCREEN_WIDTH, player, camera_x, player_group):  # Update the enemy's behavior and position
        distance_to_player = abs(self.rect.x - player.rect.x)  # Calculate the distance to the player

        if distance_to_player > 1800:  # Skip actions if the player is too far away
            return

        self.collision_rect.topleft = (self.rect.x + (self.ENEMY_SIZE - 20) // 2, self.rect.y + (self.ENEMY_SIZE - 26) // 2)  # Update the collision rect position

        if self.state == "idle":  # Behavior when idle
            if self.timetick >= self.random_wait:  # Decide the next action after waiting
                self.direction = random.choice(['left', 'right', 'nothing'])  # Randomly choose a direction or do nothing
                self.timetick = 0  # Reset the tick counter
            else:
                if self.direction == 'nothing':  # If doing nothing, increment the tick counter slower
                    self.timetick += 2
                self.timetick += 1  # Increment the tick counter

        if abs(player.rect.x - self.rect.x) <= 280 and abs(player.rect.y - self.rect.y) <= 120:  # Detect proximity to the player to start attacking
            self.state = 'attack'  # Set state to attack

        if self.state == 'attack':  # Behavior when attacking
            if self.rect.x >= player.rect.x:  # Move left if the player is to the left
                if self.statedelay >= self.random_delay:  # Wait before changing direction
                    self.direction = 'left'
                    self.statedelay = 0
                else:
                    self.statedelay += 1
            elif self.rect.x < player.rect.x:  # Move right if the player is to the right
                if self.statedelay >= self.random_delay:
                    self.direction = 'right'
                    self.statedelay = 0
                else:
                    self.statedelay += 1

        if abs(player.rect.x - self.rect.x) <= 50 and not self.is_attacking:  # Use attack animation when close enough to damage the player
            self.is_attacking = True  # Mark as attacking
            self.current_animation = 'attack'  # Play the attack animation
            self.current_frame = 0  # Restart the animation
        elif self.is_attacking:  # If already attacking, continue the attack animation
            self.current_animation = 'attack'
        elif self.state == 'attack':  # Continue running if in attack state but not attacking
            self.current_animation = 'run'
        else:  # Idle otherwise
            self.current_animation = 'idle'

        if self.direction == 'left':  # Move left if the direction is left
            self.rect.x -= self.ENEMY_SPEED
            self.facing_right = False
        elif self.direction == 'right':  # Move right if the direction is right
            self.rect.x += self.ENEMY_SPEED
            self.facing_right = True

        self.animate()  # Animate the enemy

        collided_blocks = pygame.sprite.spritecollide(self, block_group, False)  # Check for horizontal collisions with blocks
        for block in collided_blocks:  # Handle block collisions
            if self.rect.right > block.rect.left and self.rect.left < block.rect.left:  # If moving right into a block
                self.rect.right = block.rect.left
                if self.state == 'idle':
                    self.direction = 'left'
            elif self.rect.left < block.rect.right and self.rect.right > block.rect.right:  # If moving left into a block
                self.rect.left = block.rect.right
                if self.state == 'idle':
                    self.direction = 'right'

        self.vertical_velocity += self.GRAVITY  # Apply gravity

        self.rect.y += self.vertical_velocity  # Apply vertical movement

        collided_blocks = pygame.sprite.spritecollide(self, block_group, False)  # Check for vertical collisions with blocks
        self.on_ground = False  # Assume not on the ground until confirmed
        for block in collided_blocks:  # Handle vertical block collisions
            if self.rect.bottom > block.rect.top and self.rect.top < block.rect.top:  # If landing on a block
                self.rect.bottom = block.rect.top
                self.vertical_velocity = 0
                self.on_ground = True  # Confirm the enemy is on the ground
            elif self.rect.top < block.rect.bottom and self.rect.bottom > block.rect.bottom:  # If hitting the underside of a block
                self.rect.top = block.rect.bottom
                self.vertical_velocity = 0

        if self.on_ground and self.should_jump(block_group):  # If on the ground and should jump
            self.vertical_velocity = self.JUMP_STRENGTH  # Apply jump strength
            self.on_ground = False  # Set as not on the ground

    def should_jump(self, block_group):  # Determine if the enemy should jump
        if self.direction == 'right':  # Check for blocks in the path when moving right
            test_offsets = [
                (self.ENEMY_SIZE, -1 * self.ENEMY_SIZE),  # 1 block right, 1 block up
                (2 * self.ENEMY_SIZE, -1 * self.ENEMY_SIZE),  # 2 blocks right, 1 block up
                (3 * self.ENEMY_SIZE, -1 * self.ENEMY_SIZE),  # 3 blocks right, 1 block up
                (self.ENEMY_SIZE, -2 * self.ENEMY_SIZE),  # 1 block right, 2 blocks up
                (2 * self.ENEMY_SIZE, -2 * self.ENEMY_SIZE),  # 2 blocks right, 2 blocks up
                (3 * self.ENEMY_SIZE, -2 * self.ENEMY_SIZE),  # 3 blocks right, 2 blocks up
                (self.ENEMY_SIZE, -3 * self.ENEMY_SIZE),  # 1 block right, 3 blocks up
                (2 * self.ENEMY_SIZE, -3 * self.ENEMY_SIZE),  # 2 blocks right, 3 blocks up
                (3 * self.ENEMY_SIZE, -3 * self.ENEMY_SIZE)  # 3 blocks right, 3 blocks up
            ]
        elif self.direction == 'left':  # Check for blocks in the path when moving left
            test_offsets = [
                (-self.ENEMY_SIZE, -1 * self.ENEMY_SIZE),  # 1 block left, 1 block up
                (-2 * self.ENEMY_SIZE, -1 * self.ENEMY_SIZE),  # 2 blocks left, 1 block up
                (-3 * self.ENEMY_SIZE, -1 * self.ENEMY_SIZE),  # 3 blocks left, 1 block up
                (-self.ENEMY_SIZE, -2 * self.ENEMY_SIZE),  # 1 block left, 2 blocks up
                (-2 * self.ENEMY_SIZE, -2 * self.ENEMY_SIZE),  # 2 blocks left, 2 blocks up
                (-3 * self.ENEMY_SIZE, -2 * self.ENEMY_SIZE),  # 3 blocks left, 2 blocks up
                (-self.ENEMY_SIZE, -3 * self.ENEMY_SIZE),  # 1 block left, 3 blocks up
                (-2 * self.ENEMY_SIZE, -3 * self.ENEMY_SIZE),  # 2 blocks left, 3 blocks up
                (-3 * self.ENEMY_SIZE, -3 * self.ENEMY_SIZE)  # 3 blocks left, 3 blocks up
            ]
        else:
            return False

        head_rect = pygame.Rect(self.rect.x, self.rect.y - self.ENEMY_SIZE, self.ENEMY_SIZE, self.ENEMY_SIZE)  # Create a rect for the head
        upper_head_rect = pygame.Rect(self.rect.x, self.rect.y - 2 * self.ENEMY_SIZE, self.ENEMY_SIZE, self.ENEMY_SIZE)  # Create a rect for the upper head

        relevant_blocks = [block for block in block_group if self.rect.colliderect(block.rect.inflate(self.ENEMY_SIZE * 4, self.ENEMY_SIZE * 4))]  # Filter blocks near the enemy

        for block in relevant_blocks:  # Check for collisions with the head
            if head_rect.colliderect(block.rect) or upper_head_rect.colliderect(block.rect):
                return False

        for offset in test_offsets:  # Test potential jump locations
            target_x = self.rect.x + offset[0]
            target_y = self.rect.y + offset[1]

            target_rect = pygame.Rect(target_x, target_y, self.ENEMY_SIZE, self.ENEMY_SIZE)  # Create a rect for the target position
            ground_rect = pygame.Rect(target_x, target_y + self.ENEMY_SIZE, self.ENEMY_SIZE, self.ENEMY_SIZE)  # Create a rect for the ground beneath

            clear_path = True  # Assume path is clear
            ground_beneath = False  # Assume no ground beneath

            for block in relevant_blocks:  # Check for collisions with the target and ground rects
                if target_rect.colliderect(block.rect):
                    clear_path = False
                if ground_rect.colliderect(block.rect):
                    ground_beneath = True

            if clear_path and ground_beneath:  # If path is clear and there's ground beneath, jump
                return True

        return False  # No reason to jump

    def get_current_texture_index(self):  # Get the current texture index
        return self.current_texture_index  # Return the current texture index

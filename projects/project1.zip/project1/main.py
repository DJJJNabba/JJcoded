import pygame
import sys
import json
import shutil
import os
from player import Player
from enemy import Enemy
from items import Food, Water
from hud import draw_hud
from block import Block
from object import Object
from config import *
from main_menu import pause_menu
from main_menu import end_menu, next_level_menu, you_survived_menu

STATS_FILE = 'stats.txt'

# Function to copy the current script to main2.py if running as main.py
def copy_to_main2():
    current_file = os.path.basename(__file__)  # Get the current file name
    if current_file == 'main.py':  # Check if the file is named main.py
        shutil.copy(__file__, 'main2.py')  # Copy this file to main2.py

# Copy main.py to main2.py when this script is run, if named main.py
copy_to_main2()

# Initialize Pygame
pygame.init()

# Load stats from the stats.txt file
def load_stats():
    if os.path.exists(STATS_FILE):
        with open(STATS_FILE, 'r') as file:
            stats = json.load(file)
            return stats['high_score'], stats['best_time']
    return 0, float('inf')  # Default values if the file does not exist

# Save stats to the stats.txt file
def save_stats(high_score, best_time):
    stats = {'high_score': high_score, 'best_time': best_time}
    with open(STATS_FILE, 'w') as file:
        json.dump(stats, file)

# Variables to store the high score and best time
high_score, best_time = load_stats()

# Initialize high_score and best_time with default values
high_score, best_time = load_stats()  # Load from file or set defaults
if best_time == float('inf'):
    best_time = 9999  # Set a large but finite default time if no best time has been recorded

# Variables for the current level and level file
current_level = 1
level_file = 'level1.json'


# Function to load a specific level based on level number
def load_level(level_num):
    global current_level, level_file, level_map, textures

    current_level = level_num  # Set the current level number
    level_file = f'level{level_num}.json'  # Determine the level file name

    try:
        # Try to load the level map and textures from the JSON file
        level_map, textures = load_level_from_json(level_file)
        initialize_map(level_map, textures)
    except FileNotFoundError as e:
        print(e)
        # If the level file is not found, initialize with default data
        level_map, textures = [], {"X": ["textures/blocks/stone_texture.png"]}
        initialize_map(level_map, textures)

# Function to load the next level or end the game if the last level is completed
def next_level():
    global current_level
    if current_level == 2:
        # If the current level is 2, show the "You Survived" menu
        you_survived_menu(player.score, pygame.time.get_ticks() // 1000)
    else:
        # Otherwise, increment the level and load the next one
        current_level += 1
        load_level(current_level)  # Load the next level
        game_loop()  # Start the game loop for the new level

# Camera settings
camera_x = 0
camera_y = 0
CAMERA_LERP_SPEED = 0.06  # Speed at which the camera follows the player

# Colors used in the game
WHITE = (255, 255, 255)
BACKGROUND_COLOR = (131, 235, 255)

# Screen dimensions and zoom factor
SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 736
zoom_factor = 3  # Fixed 3x zoom

# Paths to the player textures
player_texture_paths = {
    'idle': 'textures/dude/Dude_Monster_Idle_4.png',
    'jump': 'textures/dude/Dude_Monster_Jump_8.png',
    'run': 'textures/dude/Dude_Monster_Run_6.png',
    'death': 'textures/dude/Dude_Monster_Death_8.png'
}

# Paths to the enemy textures
enemy_texture_paths = {
    'idle': 'textures/enemy/Owlet_Monster_Idle_4.png',
    'jump': 'textures/enemy/Owlet_Monster_Jump_8.png',
    'run': 'textures/enemy/Owlet_Monster_Run_6.png',
    'attack': 'textures/enemy/Owlet_Monster_Walk+Attack_6.png'
}

# Dictionary holding various textures used in the game
textures = {
    "X": [
        "textures/blocks/stone_texture.png",
        "textures/blocks/grass_texture.png",
        "textures/blocks/dirt_texture.png"
    ],
    "F": [
        "textures/food/food_texture_frame_1.png",
    ],
    "W": [
        "textures/water/water_texture.png"
    ],
    "P": [
        "textures/dude/Dude_Monster_Idle_4.png",
        "textures/dude/Dude_Monster_Jump_8.png",
        "textures/dude/Dude_Monster_Run_6.png",
        "textures/dude/Dude_Monster_Death_8.png"
    ],
    "E": {
        'idle': 'textures/enemy/Owlet_Monster_Idle_4.png',
        'jump': 'textures/enemy/Owlet_Monster_Jump_8.png',
        'run': 'textures/enemy/Owlet_Monster_Run_6.png',
        'attack': 'textures/enemy/Owlet_Monster_Walk+Attack_6.png'
    },
    "O": [
        "textures/heli/heli_texture1.png",
        "textures/heli/heli_texture2.png",
    ]
}

# Create the game window with a fixed size
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.NOFRAME)
pygame.display.set_caption("Survival Game")

# Create sprite groups for different types of game entities
player_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
food_group = pygame.sprite.Group()
water_group = pygame.sprite.Group()
block_group = pygame.sprite.Group()
object_group = pygame.sprite.Group()  # Group for objects like the helicopter

# Font for displaying FPS (Frames Per Second)
font = pygame.font.Font(None, 36)

# Function to load the level data from a JSON file
def load_level_from_json(filename):
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            data = json.load(file)  # Load the JSON data
        return data['level'], data['textures']  # Return the level map and textures
    else:
        raise FileNotFoundError(f"No saved level found at {filename}")

# Initialize variables to store the player's spawn position
player_spawn_x = 0
player_spawn_y = 0

# Function to initialize the game map based on the loaded level data
def initialize_map(level_map, textures):
    global player_spawn_x, player_spawn_y
    
    # Clear all sprite groups to prepare for loading the new map
    block_group.empty()
    food_group.empty()
    water_group.empty()
    player_group.empty()
    enemy_group.empty()
    object_group.empty()

    # Loop through each block in the level map and create the corresponding game objects
    for block_data in level_map:
        x = block_data['x'] * GRID_SIZE
        y = block_data['y'] * GRID_SIZE
        texture_index = block_data['texture_index']
        block_type = block_data['type']
        
        if block_type == 'X':  # If the block type is 'X', create a Block
            block = Block(x, y, textures['X'], texture_index)
            block_group.add(block)
        elif block_type == 'F':  # If the block type is 'F', create Food
            food = Food(x, y, textures['F'], texture_index)
            food_group.add(food)
        elif block_type == 'W':  # If the block type is 'W', create Water
            water = Water(x, y, textures['W'], texture_index)
            water_group.add(water)
        elif block_type == 'P':  # If the block type is 'P', create a Player
            player = Player(x, y, player_texture_paths, level_map, GRID_SIZE, texture_index)
            player_group.add(player)
            player_spawn_x = x  # Store the player's spawn position
            player_spawn_y = y
        elif block_type == 'E':  # If the block type is 'E', create an Enemy
            enemy = Enemy(x, y, enemy_texture_paths, level_map, GRID_SIZE, texture_index)
            enemy_group.add(enemy)
        elif block_type == 'O':  # If the block type is 'O', create an Object (e.g., helicopter)
            object = Object(x, y, textures['O'], texture_index)
            object_group.add(object)

# Function to draw the game world, scaling it according to the zoom factor
def draw_world():
    # Define the visible area of the screen based on the camera position and zoom factor
    visible_rect = pygame.Rect(camera_x, camera_y, SCREEN_WIDTH + 30 / zoom_factor, SCREEN_HEIGHT + 30 / zoom_factor)

    # Draw all blocks within the visible area
    for block in block_group:
        if visible_rect.colliderect(block.rect):
            scaled_image = pygame.transform.scale(block.image, (int(block.rect.width * zoom_factor), int(block.rect.height * zoom_factor)))
            screen.blit(scaled_image, (round((block.rect.x - camera_x) * zoom_factor), round((block.rect.y - camera_y) * zoom_factor)))
        
    # Draw all objects within the visible area
    for object in object_group:
        if visible_rect.colliderect(object.rect):
            scaled_image = pygame.transform.scale(object.image, (int(object.rect.width * zoom_factor), int(object.rect.height * zoom_factor)))
            screen.blit(scaled_image, (round((object.rect.x - camera_x) * zoom_factor), round((object.rect.y - camera_y) * zoom_factor)))

    # Draw all sprites within the visible area
    for sprite_group in [block_group, food_group, water_group, player_group, enemy_group, object_group]:
        for sprite in sprite_group:
            if visible_rect.colliderect(sprite.rect):
                scaled_image = pygame.transform.scale(sprite.image, (int(sprite.rect.width * zoom_factor), int(sprite.rect.height * zoom_factor)))
                screen.blit(scaled_image, (round((sprite.rect.x - camera_x) * zoom_factor), round((sprite.rect.y - camera_y) * zoom_factor)))

    # Draw the player's HUD (Health, score, etc.)
    for player in player_group:
        draw_hud(screen, player, high_score, best_time)

# Load the initial level
try:
    load_level(1)
except FileNotFoundError as e:
    print(e)
    # If the level file is not found, initialize with default data
    level_map, textures = [], {"X": ["textures/blocks/stone_texture.png"]}
    initialize_map(level_map, textures)

# Initialize the camera position based on the player's position
if player_group:
    player = player_group.sprites()[0]
    camera_x = max(0, player.rect.centerx - SCREEN_WIDTH // (2 * zoom_factor))
    camera_y = max(0, player.rect.centery - SCREEN_HEIGHT // (2 * zoom_factor))
else:
    camera_x = camera_y = 0

# Calculate the level dimensions in pixels
level_width_in_pixels = max(block.rect.right for block in block_group) if block_group else SCREEN_WIDTH
level_height_in_pixels = max(block.rect.bottom for block in block_group) if block_group else SCREEN_HEIGHT
camera_x = min(camera_x, level_width_in_pixels - SCREEN_WIDTH // zoom_factor)
camera_y = min(camera_y, level_height_in_pixels - SCREEN_HEIGHT // zoom_factor)

# Main game loop variables
running = True
clock = pygame.time.Clock()

# Main game loop
def game_loop():
    global running, camera_x, camera_y, high_score, best_time
    running = True

    # Ensure the player is correctly assigned
    if player_group:
        player = player_group.sprites()[0]
        player.rect.x = player_spawn_x
        player.rect.y = player_spawn_y

        # Reset the camera position to match the player's new position
        camera_x = max(0, player.rect.centerx - SCREEN_WIDTH // (2 * zoom_factor))
        camera_y = max(0, player.rect.centery - SCREEN_HEIGHT // (2 * zoom_factor))
        camera_x = min(camera_x, level_width_in_pixels - SCREEN_WIDTH // zoom_factor)
        camera_y = min(camera_y, level_height_in_pixels - SCREEN_HEIGHT // zoom_factor)
    else:
        # Handle the case where no player is found in the group
        print("Error: No player found in the player group.")
        return
    
    while running:
        dt = clock.tick(60) / 1000  # Time since the last frame in seconds
        fps = clock.get_fps()  # Current frames per second

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause_menu()  # Call the pause menu
                elif event.key == pygame.K_PERIOD:  # Check if the '.' key is pressed
                    print(f"Player X: {player.rect.x}")
                    print(f"Camera X: {camera_x}, Camera Y: {camera_y}")
                    print(f"Zoom Factor: {zoom_factor}")
                    print(f"Target Camera X: {target_camera_x}, Target Camera Y: {target_camera_y}")
                    you_survived_menu(player.score, pygame.time.get_ticks() // 1000)
                    # Teleport player to spawn position
                    for player in player_group:
                        player.rect.x = player_spawn_x
                        player.rect.y = player_spawn_y

                    # Reset the camera position to match the player's new position
                    camera_x = max(0, player.rect.centerx - SCREEN_WIDTH // (2 * zoom_factor))
                    camera_y = max(0, player.rect.centery - SCREEN_HEIGHT // (2 * zoom_factor))
                    camera_x = min(camera_x, level_width_in_pixels - SCREEN_WIDTH // zoom_factor)
                    camera_y = min(camera_y, level_height_in_pixels - SCREEN_HEIGHT // zoom_factor)

        # Update the player and enemy positions
        player_group.update(block_group, camera_x, SCREEN_WIDTH, level_map, enemy_group, object_group, food_group, water_group)

        for player in player_group: 
            enemy_group.update(block_group, SCREEN_WIDTH, player, camera_x, player_group)
        
        # Update the food, water, and objects
        food_group.update(dt)
        water_group.update(dt)
        object_group.update(dt)

        # Check if the player is dead and the death animation is complete
        if player.is_dead and player.death_animation_complete:
            # Update high score and best time
            time_alive = pygame.time.get_ticks() // 1000
            if player.score > high_score:
                high_score = player.score
            if time_alive < best_time:
                best_time = time_alive
            save_stats(high_score, best_time)  # Save the updated stats
            end_menu(player.score, time_alive)

        # Check for collisions with objects (e.g., helicopter)
        for player in player_group:
            object_collisions = pygame.sprite.spritecollide(player, object_group, False)
            
            if object_collisions:
                time_alive = pygame.time.get_ticks() // 1000
                if player.score > high_score:
                    high_score = player.score
                if time_alive < best_time:
                    best_time = time_alive
                save_stats(high_score, best_time)  # Save the updated stats
                you_survived_menu(player.score, time_alive)
                """next_level()
                for player in player_group:
                    player.rect.x = player_spawn_x
                    player.rect.y = player_spawn_y

                    # Reset the camera position to match the player's new position
                    camera_x = max(0, player.rect.centerx - SCREEN_WIDTH // (2 * zoom_factor))
                    camera_y = max(0, player.rect.centery - SCREEN_HEIGHT // (2 * zoom factor))
                    camera_x = min(camera_x, level_width_in_pixels - SCREEN_WIDTH // zoom factor)
                    camera_y = min(camera_y, level_height_in_pixels - SCREEN_HEIGHT // zoom factor)
            else:
                pass"""

        # Smooth camera movement to follow the player
        for player in player_group:
            target_camera_x = player.rect.centerx - SCREEN_WIDTH // (2 * zoom_factor)
            target_camera_y = player.rect.centery - SCREEN_HEIGHT // (2 * zoom_factor)
            target_camera_x = max(0, target_camera_x)
            target_camera_y = max(0, target_camera_y)
            target_camera_x = min(target_camera_x, level_width_in_pixels - SCREEN_WIDTH // zoom_factor)
            target_camera_y = min(target_camera_y, level_height_in_pixels - SCREEN_HEIGHT // zoom_factor)
            camera_x += (target_camera_x - camera_x) * CAMERA_LERP_SPEED
            camera_y += (target_camera_y - camera_y) * CAMERA_LERP_SPEED

        screen.fill(BACKGROUND_COLOR)  # Clear the screen with the background color
        draw_world()  # Draw the game world

        # Display the FPS on the screen
        fps_text = font.render(f"FPS: {int(fps)}", True, WHITE)
        screen.blit(fps_text, (SCREEN_WIDTH - 100, 10))

        pygame.display.update()  # Update the display
        clock.tick(60)  # Limit the frame rate to 60 FPS

    pygame.quit()  # Quit Pygame when the loop ends
    sys.exit()  # Exit the program

    game_loop()

# Run the game if this script is executed directly
if __name__ == "__main__":
    load_level(1)  # Load the first level
    game_loop()  # Start the game loop


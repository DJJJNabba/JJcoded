# file_watcher.py
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import shutil

class FileChangeHandler(FileSystemEventHandler):
    def __init__(self, src, dst):
        self.src = src
        self.dst = dst

    def on_modified(self, event):
        if event.src_path == self.src:
            shutil.copy(self.src, self.dst)
            print(f"Copied {self.src} to {self.dst}")

if __name__ == "__main__":
    src_file = 'main.py'
    dst_file = 'main2.py'

    event_handler = FileChangeHandler(src_file, dst_file)
    observer = Observer()
    observer.schedule(event_handler, path='.', recursive=False)
    observer.start()
    print(f"Watching for changes in {src_file}...")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

import pygame  # Import the Pygame library for handling graphics and events
import sys  # Import the sys library for system-specific parameters and functions
import os  # Import the os library for interacting with the operating system
import json  # Import the json library for handling JSON data

# Function to initialize Pygame components (to be reused)
def init_pygame():
    pygame.init()  # Initialize all Pygame modules
    global screen  # Declare the screen variable as global
    screen = pygame.display.set_mode((1280, 736), pygame.NOFRAME)  # Create a Pygame window with a resolution of 1280x736 and no window frame
    pygame.display.set_caption("Atomic Dawn")  # Set the window title to "Atomic Dawn"

# Initialize Pygame
init_pygame()  # Call the function to initialize Pygame

# Colors
WHITE = (255, 255, 255)  # Define the color white
GRAY = (50, 50, 50)  # Define a shade of gray
BLACK = (0, 0, 0)  # Define the color black
BUTTON_COLOR = (100, 100, 100)  # Define the default button color
HOVER_COLOR = (150, 150, 150)  # Define the button color when hovered

# Load and scale background image
background_image = pygame.image.load("textures/background/backgroundfrfr.jpg").convert_alpha()  # Load the background image and convert it to include an alpha channel
background_image = pygame.transform.scale(background_image, (1280, 736))  # Scale the background image to fit the screen

# Function to draw text on the screen
def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)  # Render the text with the specified font and color
    text_rect = text_obj.get_rect(center=(x, y))  # Get the rectangle surrounding the text and center it at (x, y)
    surface.blit(text_obj, text_rect)  # Draw the text on the specified surface at the calculated position

# Function to display the main menu
def main_menu():
    if not pygame.get_init():  # Check if Pygame is initialized
        init_pygame()  # Reinitialize Pygame if not already initialized
    init_pygame()  # Reinitialize Pygame components
    title_font = pygame.font.Font(None, 100)  # Set the font for the title text
    small_font = pygame.font.Font(None, 50)  # Set the font for the button text
    running = True  # Set a flag to keep the menu running
    
    while running:  # Main menu loop
        screen.blit(background_image, (0, 0))  # Draw the background image on the screen
        overlay = pygame.Surface((1280, 736))  # Create an overlay surface
        overlay.set_alpha(180)  # Set the overlay's transparency (alpha value)
        overlay.fill(BLACK)  # Fill the overlay with black color
        screen.blit(overlay, (0, 0))  # Draw the overlay on top of the background

        # Draw the title at the top third of the screen
        draw_text('Atomic Dawn', title_font, WHITE, screen, 1280 // 2, 736 // 6 * 1.3)  # Draw the game title text centered at the specified position
        
        # Define button positions and sizes
        button_width, button_height = 300, 100  # Set the width and height of the buttons
        button_spacing = 50  # Set the space between buttons
        total_height = 3 * button_height + 2 * button_spacing  # Calculate the total height occupied by the buttons
        start_y = ((736 * 2 // 3 - total_height) // 2 + 736 // 3) - 40  # Calculate the starting Y position for the first button
        
        # Create rectangles for each button
        play_button = pygame.Rect(1280 // 2 - button_width // 2, start_y, button_width, button_height)  # Play button
        level_editor_button = pygame.Rect(1280 // 2 - button_width // 2, start_y + button_height + button_spacing, button_width, button_height)  # Level editor button
        quit_button = pygame.Rect(1280 // 2 - button_width // 2, start_y + 2 * (button_height + button_spacing), button_width, button_height)  # Quit button
        
        # Handle hover effect
        mouse_pos = pygame.mouse.get_pos()  # Get the current mouse position

        # Iterate over each button and its corresponding text
        for button, text in [(play_button, 'Play'), (level_editor_button, 'Level Editor'), (quit_button, 'Quit')]:
            if button.collidepoint(mouse_pos):  # Check if the mouse is hovering over the button
                color = HOVER_COLOR  # Change the button color if hovered
            else:
                color = BUTTON_COLOR  # Use the default button color
            pygame.draw.rect(screen, color, button, border_radius=20)  # Draw the button with rounded corners
            draw_text(text, small_font, WHITE, screen, button.centerx, button.centery)  # Draw the button text centered on the button
        
        # Handle events
        for event in pygame.event.get():  # Iterate over all Pygame events
            if event.type == pygame.QUIT:  # Check if the quit event is triggered
                running = False  # Stop the menu loop
                pygame.quit()  # Quit Pygame
                sys.exit()  # Exit the program
            elif event.type == pygame.MOUSEBUTTONDOWN:  # Check if a mouse button is pressed
                if play_button.collidepoint(event.pos):  # If the play button is clicked
                    running = False  # Exit the menu loop and start the game
                    reset_to_level_1()  # Reset the game to start from level 1
                elif level_editor_button.collidepoint(event.pos):  # If the level editor button is clicked
                    running = False  # Exit the menu loop and start the level editor
                    level_editor_loop()  # Call the level editor loop
                elif quit_button.collidepoint(event.pos):  # If the quit button is clicked
                    running = False  # Stop the menu loop
                    pygame.quit()  # Quit Pygame
                    sys.exit()  # Exit the program
        
        pygame.display.flip()  # Update the display with the latest changes

# Function to reset the game to start from level 1
def reset_to_level_1():
    """Reset the game to start from level 1."""
    from main2 import load_level, game_loop  # Import the functions from main2
    load_level(1)  # Load level 1
    game_loop()  # Start the game loop

# Function to display the game over menu
def end_menu(score, time_alive):
    font = pygame.font.Font(None, 74)  # Set the font for the title text
    small_font = pygame.font.Font(None, 50)  # Set the font for the score and time text
    running = True  # Set a flag to keep the menu running

    # Capture the current screen to apply blur
    end_screen = pygame.Surface((1280, 736))  # Create a surface for capturing the screen
    pygame.display.flip()  # Update the display to ensure everything is rendered
    pygame.time.wait(100)  # Wait for 100 milliseconds to ensure the screen is updated before capturing
    end_screen.blit(screen, (0, 0))  # Capture the current screen content
    blurred_screen = pygame.transform.smoothscale(end_screen, (320, 184))  # Downscale the captured screen for blurring
    blurred_screen = pygame.transform.smoothscale(blurred_screen, (1280, 736))  # Upscale back to original size to create a blur effect
    
    while running:  # Game over menu loop
        screen.blit(blurred_screen, (0, 0))  # Draw the blurred screen
        overlay = pygame.Surface((1280, 736))  # Create an overlay surface
        overlay.set_alpha(128)  # Set the overlay's transparency (alpha value)
        overlay.fill(BLACK)  # Fill the overlay with black color
        screen.blit(overlay, (0, 0))  # Draw the overlay on top of the blurred screen

        # Draw the game over text and score/time
        draw_text('Game Over', font, WHITE, screen, 1280 // 2, 736 // 4)  # Draw the "Game Over" text at the top
        draw_text(f'Score: {int(score)}', small_font, WHITE, screen, 1280 // 2, 736 // 2 - 50)  # Draw the score text below the title
        draw_text(f'Time Alive: {int(time_alive)}s', small_font, WHITE, screen, 1280 // 2, 736 // 2 + 50)  # Draw the time alive text below the score
        
        main_menu_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 150, 300, 100)  # Create a rectangle for the main menu button
        
        pygame.draw.rect(screen, BUTTON_COLOR, main_menu_button, border_radius=20)  # Draw the main menu button
        draw_text('Main Menu', small_font, WHITE, screen, main_menu_button.centerx, main_menu_button.centery)  # Draw the "Main Menu" text on the button
        
        for event in pygame.event.get():  # Iterate over all Pygame events
            if event.type == pygame.QUIT:  # Check if the quit event is triggered
                running = False  # Stop the menu loop
                pygame.quit()  # Quit Pygame
                sys.exit()  # Exit the program
            elif event.type == pygame.MOUSEBUTTONDOWN:  # Check if a mouse button is pressed
                if main_menu_button.collidepoint(event.pos):  # If the main menu button is clicked
                    running = False  # Stop the menu loop
                    main_menu()  # Go back to the main menu
                    return  # Exit the function
        
        pygame.display.flip()  # Update the display with the latest changes

# Function to display the level complete menu
def next_level_menu():
    font = pygame.font.Font(None, 74)  # Set the font for the title text
    small_font = pygame.font.Font(None, 50)  # Set the font for the button text
    running = True  # Set a flag to keep the menu running

    # Capture the current screen to apply blur
    next_screen = pygame.Surface((1280, 736))  # Create a surface for capturing the screen
    pygame.display.flip()  # Update the display to ensure everything is rendered
    pygame.time.wait(100)  # Wait for 100 milliseconds to ensure the screen is updated before capturing
    next_screen.blit(screen, (0, 0))  # Capture the current screen content
    blurred_screen = pygame.transform.smoothscale(next_screen, (320, 184))  # Downscale the captured screen for blurring
    blurred_screen = pygame.transform.smoothscale(blurred_screen, (1280, 736))  # Upscale back to original size to create a blur effect
    
    while running:  # Level complete menu loop
        screen.blit(blurred_screen, (0, 0))  # Draw the blurred screen
        overlay = pygame.Surface((1280, 736))  # Create an overlay surface
        overlay.set_alpha(128)  # Set the overlay's transparency (alpha value)
        overlay.fill(BLACK)  # Fill the overlay with black color
        screen.blit(overlay, (0, 0))  # Draw the overlay on top of the blurred screen

        draw_text('Level Complete', font, WHITE, screen, 1280 // 2, 736 // 4)  # Draw the "Level Complete" text at the top
        
        next_level_button = pygame.Rect(1280 // 2 - 150, 736 // 2 - 50, 300, 100)  # Create a rectangle for the next level button
        main_menu_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 100, 300, 100)  # Create a rectangle for the main menu button
        
        pygame.draw.rect(screen, BUTTON_COLOR, next_level_button, border_radius=20)  # Draw the next level button
        draw_text('Next Level', small_font, WHITE, screen, next_level_button.centerx, next_level_button.centery)  # Draw the "Next Level" text on the button
        
        pygame.draw.rect(screen, BUTTON_COLOR, main_menu_button, border_radius=20)  # Draw the main menu button
        draw_text('Main Menu', small_font, WHITE, screen, main_menu_button.centerx, main_menu_button.centery)  # Draw the "Main Menu" text on the button
        
        for event in pygame.event.get():  # Iterate over all Pygame events
            if event.type == pygame.QUIT:  # Check if the quit event is triggered
                running = False  # Stop the menu loop
                pygame.quit()  # Quit Pygame
                sys.exit()  # Exit the program
            elif event.type == pygame.MOUSEBUTTONDOWN:  # Check if a mouse button is pressed
                if next_level_button.collidepoint(event.pos):  # If the next level button is clicked
                    running = False  # Stop the menu loop
                    from main2 import load_level  # Import the load_level function from main2
                    load_level(2)  # Load the second level
                elif main_menu_button.collidepoint(event.pos):  # If the main menu button is clicked
                    running = False  # Stop the menu loop
                    main_menu()  # Go back to the main menu
                    return  # Exit the function
        
        pygame.display.flip()  # Update the display with the latest changes

# Function to display the "You Survived" menu
def you_survived_menu(score, time_alive):
    font = pygame.font.Font(None, 74)  # Set the font for the title text
    small_font = pygame.font.Font(None, 50)  # Set the font for the score and time text
    running = True  # Set a flag to keep the menu running

    # Capture the current screen to apply blur
    survived_screen = pygame.Surface((1280, 736))  # Create a surface for capturing the screen
    pygame.display.flip()  # Update the display to ensure everything is rendered
    pygame.time.wait(100)  # Wait for 100 milliseconds to ensure the screen is updated before capturing
    survived_screen.blit(screen, (0, 0))  # Capture the current screen content
    blurred_screen = pygame.transform.smoothscale(survived_screen, (320, 184))  # Downscale the captured screen for blurring
    blurred_screen = pygame.transform.smoothscale(blurred_screen, (1280, 736))  # Upscale back to original size to create a blur effect
    
    while running:  # "You Survived" menu loop
        screen.blit(blurred_screen, (0, 0))  # Draw the blurred screen
        overlay = pygame.Surface((1280, 736))  # Create an overlay surface
        overlay.set_alpha(128)  # Set the overlay's transparency (alpha value)
        overlay.fill(BLACK)  # Fill the overlay with black color
        screen.blit(overlay, (0, 0))  # Draw the overlay on top of the blurred screen

        draw_text('YOU SURVIVED', font, WHITE, screen, 1280 // 2, 736 // 4)  # Draw the "YOU SURVIVED" text at the top
        draw_text(f'Score: {int(score)}', small_font, WHITE, screen, 1280 // 2, 736 // 2 - 50)  # Draw the score text below the title
        draw_text(f'Time Taken: {int(time_alive)}s', small_font, WHITE, screen, 1280 // 2, 736 // 2 + 50)  # Draw the time alive text below the score
        
        main_menu_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 150, 300, 100)  # Create a rectangle for the main menu button
        
        pygame.draw.rect(screen, BUTTON_COLOR, main_menu_button, border_radius=20)  # Draw the main menu button
        draw_text('Main Menu', small_font, WHITE, screen, main_menu_button.centerx, main_menu_button.centery)  # Draw the "Main Menu" text on the button
        
        for event in pygame.event.get():  # Iterate over all Pygame events
            if event.type == pygame.QUIT:  # Check if the quit event is triggered
                running = False  # Stop the menu loop
                pygame.quit()  # Quit Pygame
                sys.exit()  # Exit the program
            elif event.type == pygame.MOUSEBUTTONDOWN:  # Check if a mouse button is pressed
                if main_menu_button.collidepoint(event.pos):  # If the main menu button is clicked
                    running = False  # Stop the menu loop
                    main_menu()  # Go back to the main menu
                    return  # Exit the function
        
        pygame.display.flip()  # Update the display with the latest changes

# Function to initialize level 2 and start the game loop
def initialize_level2():
    """Load the second level and start the game loop."""
    from main import load_level_from_json, initialize_map, game_loop  # Import the necessary functions from main

    level_file = 'level2.json'  # Specify the filename of the second level's JSON file
    try:
        level_map, textures = load_level_from_json(level_file)  # Try to load the level map and textures from the JSON file
        initialize_map(level_map, textures)  # Initialize the map with the loaded data
    except FileNotFoundError as e:  # If the file is not found
        print(e)  # Print the error message
        level_map, textures = [], {"X": ["textures/blocks/stone_texture.png"]}  # Use default textures if file not found
        initialize_map(level_map, textures)  # Initialize the map with default data

    game_loop()  # Start the game loop for level 2

# Function to start the game from level 1
def start_game():
    """Load the level and start the game loop."""
    from main2 import game_loop, load_level_from_json, initialize_map  # Import the necessary functions from main2

    level_file = 'level1.json'  # Specify the filename of the first level's JSON file
    try:
        level_map, textures = load_level_from_json(level_file)  # Try to load the level map and textures from the JSON file
        initialize_map(level_map, textures)  # Initialize the map with the loaded data
    except FileNotFoundError as e:  # If the file is not found
        print(e)  # Print the error message
        level_map, textures = [], {"X": ["textures/blocks/stone_texture.png"]}  # Use default textures if file not found
        initialize_map(level_map, textures)  # Initialize the map with default data

    game_loop()  # Start the game loop for level 1

# Function to load level data from a JSON file
def load_level_from_json(filename):
    if os.path.exists(filename):  # Check if the file exists
        print(f"Loading level from {filename}")  # Print a message indicating that the level is being loaded
        with open(filename, 'r') as file:  # Open the file in read mode
            data = json.load(file)  # Load the JSON data from the file
        return data['level'], data['textures']  # Return the level map and textures
    else:
        print(f"No saved level found at {filename}")  # Print a message if the file is not found
        raise FileNotFoundError(f"No saved level found at {filename}")  # Raise a FileNotFoundError

# Function to start the level editor
def level_editor_loop():
    import LevelEditor  # Import the LevelEditor module
    from main2 import game_loop, load_level_from_json, initialize_map  # Import necessary functions from main2
    
    level_file = 'level1.json'  # Specify the filename of the first level's JSON file
    try:
        level_map, textures = load_level_from_json(level_file)  # Try to load the level map and textures from the JSON file
        initialize_map(level_map, textures)  # Initialize the map with the loaded data
    except FileNotFoundError as e:  # If the file is not found
        print(e)  # Print the error message
        textures = {"X": ["textures/blocks/stone_texture.png"]}  # Use default textures if file not found

    LevelEditor.main(textures)  # Pass textures to the LevelEditor main function

# Function to display the pause menu
def pause_menu():
    font = pygame.font.Font(None, 74)  # Set the font for the title text
    small_font = pygame.font.Font(None, 50)  # Set the font for the button text
    paused = True  # Set a flag to keep the pause menu running
    
    # Capture the current screen to apply blur
    paused_screen = pygame.Surface((1280, 736))  # Create a surface for capturing the screen
    pygame.display.flip()  # Update the display to ensure everything is rendered
    pygame.time.wait(100)  # Wait for 100 milliseconds to ensure the screen is updated before capturing
    paused_screen.blit(screen, (0, 0))  # Capture the current screen content
    blurred_screen = pygame.transform.smoothscale(paused_screen, (320, 184))  # Downscale the captured screen for blurring
    blurred_screen = pygame.transform.smoothscale(blurred_screen, (1280, 736))  # Upscale back to original size to create a blur effect
    
    while paused:  # Pause menu loop
        screen.blit(blurred_screen, (0, 0))  # Draw the blurred screen
        overlay = pygame.Surface((1280, 736))  # Create an overlay surface
        overlay.set_alpha(128)  # Set the overlay's transparency (alpha value)
        overlay.fill(BLACK)  # Fill the overlay with black color
        screen.blit(overlay, (0, 0))  # Draw the overlay on top of the blurred screen

        draw_text('Paused', font, WHITE, screen, 1280 // 2, 736 // 4)  # Draw the "Paused" text at the top
        
        resume_button = pygame.Rect(1280 // 2 - 150, 736 // 2 - 50, 300, 100)  # Create a rectangle for the resume button
        main_menu_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 100, 300, 100)  # Create a rectangle for the main menu button
        quit_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 250, 300, 100)  # Create a rectangle for the quit button
        
        pygame.draw.rect(screen, BUTTON_COLOR, resume_button, border_radius=20)  # Draw the resume button
        draw_text('Resume', small_font, WHITE, screen, resume_button.centerx, resume_button.centery)  # Draw the "Resume" text on the button
        
        pygame.draw.rect(screen, BUTTON_COLOR, main_menu_button, border_radius=20)  # Draw the main menu button
        draw_text('Main Menu', small_font, WHITE, screen, main_menu_button.centerx, main_menu_button.centery)  # Draw the "Main Menu" text on the button
        
        pygame.draw.rect(screen, BUTTON_COLOR, quit_button, border_radius=20)  # Draw the quit button
        draw_text('Quit', small_font, WHITE, screen, quit_button.centerx, quit_button.centery)  # Draw the "Quit" text on the button
        
        for event in pygame.event.get():  # Iterate over all Pygame events
            if event.type == pygame.QUIT:  # Check if the quit event is triggered
                paused = False  # Exit the pause menu loop
                pygame.quit()  # Quit Pygame
                sys.exit()  # Exit the program
            elif event.type == pygame.KEYDOWN:  # Check if a key is pressed
                if event.key == pygame.K_ESCAPE:  # If the escape key is pressed
                    paused = False  # Unpause the game
            elif event.type == pygame.MOUSEBUTTONDOWN:  # Check if a mouse button is pressed
                if resume_button.collidepoint(event.pos):  # If the resume button is clicked
                    paused = False  # Resume the game
                elif main_menu_button.collidepoint(event.pos):  # If the main menu button is clicked
                    paused = False  # Exit the pause menu loop
                    main_menu()  # Go back to the main menu
                    return  # Exit the function
                elif quit_button.collidepoint(event.pos):  # If the quit button is clicked
                    paused = False  # Exit the pause menu loop
                    pygame.quit()  # Quit Pygame
                    sys.exit()  # Exit the program
        
        pygame.display.flip()  # Update the display with the latest changes

# Start the main menu when the script is executed directly
if __name__ == "__main__":
    main_menu()  # Call the main menu function

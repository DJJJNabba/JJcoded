import pygame
import sys

# Function to initialize Pygame components (to be reused)
def init_pygame():
    pygame.init()
    global screen
    screen = pygame.display.set_mode((1280, 736), pygame.NOFRAME)
    pygame.display.set_caption("Atomic Dawn")

# Initialize Pygame
init_pygame()

# Colors
WHITE = (255, 255, 255)
GRAY = (50, 50, 50)
BLACK = (0, 0, 0)
BUTTON_COLOR = (100, 100, 100)
HOVER_COLOR = (150, 150, 150)
SCROLLING_BACKGROUND = 'textures/scrollingBackground/scrollingbackground.png'

# Load and scale background image
background_image = pygame.image.load("textures/background/backgroundfrfr.jpg").convert_alpha()
background_image = pygame.transform.scale(background_image, (1280, 736))

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect(center=(x, y))
    surface.blit(text_obj, text_rect)

def main_menu():
    init_pygame()  # Reinitialize Pygame when starting the main menu
    
    title_font = pygame.font.Font(None, 100)
    small_font = pygame.font.Font(None, 50)
    running = True
    
    while running:
        screen.blit(background_image, (0, 0))
        overlay = pygame.Surface((1280, 736))
        overlay.set_alpha(180)
        overlay.fill(BLACK)
        screen.blit(overlay, (0, 0))

        # Draw the title at the top third
        draw_text('Atomic Dawn', title_font, WHITE, screen, 1280 // 2, 736 // 6 * 1.3)
        
        # Define button positions and sizes
        button_width, button_height = 300, 100
        button_spacing = 50  # Space between buttons
        total_height = 3 * button_height + 2 * button_spacing
        start_y = ((736 * 2 // 3 - total_height) // 2 + 736 // 3) - 40  # Move buttons up by 40 pixels
        
        play_button = pygame.Rect(1280 // 2 - button_width // 2, start_y, button_width, button_height)
        level_editor_button = pygame.Rect(1280 // 2 - button_width // 2, start_y + button_height + button_spacing, button_width, button_height)
        quit_button = pygame.Rect(1280 // 2 - button_width // 2, start_y + 2 * (button_height + button_spacing), button_width, button_height)
        
        # Handle hover effect
        mouse_pos = pygame.mouse.get_pos()

        for button, text in [(play_button, 'Play'), (level_editor_button, 'Level Editor'), (quit_button, 'Quit')]:
            if button.collidepoint(mouse_pos):
                color = HOVER_COLOR
            else:
                color = BUTTON_COLOR
            pygame.draw.rect(screen, color, button, border_radius=20)
            draw_text(text, small_font, WHITE, screen, button.centerx, button.centery)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):
                    running = False  # Exit the menu loop and start the game
                    start_game()
                elif level_editor_button.collidepoint(event.pos):
                    running = False  # Exit the menu loop and start the level editor
                    level_editor_loop()
                elif quit_button.collidepoint(event.pos):
                    running = False
                    pygame.quit()
                    sys.exit()
        
        pygame.display.flip()

def start_game():
    """Load the level and start the game loop."""
    from main2 import game_loop, load_level_from_json, initialize_map

    level_file = 'level1.json'
    try:
        level_map, textures = load_level_from_json(level_file)
        initialize_map(level_map, textures)
    except FileNotFoundError as e:
        print(e)
        level_map, textures = [], {"X": ["textures/blocks/stone_texture.png"]}
        initialize_map(level_map, textures)

    game_loop()

def level_editor_loop():
    import LevelEditor
    LevelEditor.main()

def pause_menu():
    font = pygame.font.Font(None, 74)
    small_font = pygame.font.Font(None, 50)
    paused = True
    
    # Capture the current screen to apply blur
    paused_screen = pygame.Surface((1280, 736))
    pygame.display.flip()
    pygame.time.wait(100)  # Ensuring the screen is updated before capturing
    paused_screen.blit(screen, (0, 0))
    blurred_screen = pygame.transform.smoothscale(paused_screen, (320, 184))
    blurred_screen = pygame.transform.smoothscale(blurred_screen, (1280, 736))
    
    while paused:
        screen.blit(blurred_screen, (0, 0))
        overlay = pygame.Surface((1280, 736))
        overlay.set_alpha(128)
        overlay.fill(BLACK)
        screen.blit(overlay, (0, 0))

        draw_text('Paused', font, WHITE, screen, 1280 // 2, 736 // 4)
        
        resume_button = pygame.Rect(1280 // 2 - 150, 736 // 2 - 50, 300, 100)
        main_menu_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 100, 300, 100)
        quit_button = pygame.Rect(1280 // 2 - 150, 736 // 2 + 250, 300, 100)
        
        pygame.draw.rect(screen, BUTTON_COLOR, resume_button, border_radius=20)
        draw_text('Resume', small_font, WHITE, screen, resume_button.centerx, resume_button.centery)
        
        pygame.draw.rect(screen, BUTTON_COLOR, main_menu_button, border_radius=20)
        draw_text('Main Menu', small_font, WHITE, screen, main_menu_button.centerx, main_menu_button.centery)
        
        pygame.draw.rect(screen, BUTTON_COLOR, quit_button, border_radius=20)
        draw_text('Quit', small_font, WHITE, screen, quit_button.centerx, quit_button.centery)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                paused = False
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    paused = False  # Unpause the game
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if resume_button.collidepoint(event.pos):
                    paused = False  # Resume the game
                elif main_menu_button.collidepoint(event.pos):
                    paused = False
                    main_menu()  # Go back to the main menu
                    return
                elif quit_button.collidepoint(event.pos):
                    paused = False
                    pygame.quit()
                    sys.exit()
        
        pygame.display.flip()

if __name__ == "__main__":
    main_menu()

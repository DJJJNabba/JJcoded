from PIL import Image
import os

def check_icc_profile(image_path):
    try:
        with Image.open(image_path) as img:
            icc_profile = img.info.get("icc_profile", None)
            if icc_profile:
                pass
                # print(f"Image '{image_path}' contains an ICC profile.")
            else:
                print(f"Image '{image_path}' does not contain an ICC profile.")
    except Exception as e:
        print(f"Could not process image '{image_path}': {e}")

def check_images_in_directory(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(".png"):
                file_path = os.path.join(root, file)
                check_icc_profile(file_path)

# Specify the root directory containing your textures folder
root_directory = "textures"

# Check all PNG images within the textures directory and its subdirectories
check_images_in_directory(root_directory)
